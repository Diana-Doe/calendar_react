import {kitty} from "../../images";

const Home = () => {
    return (
        <section className="Home">
            <h1>Welcome to calendar!</h1>
            <img src={kitty} className="KITTY_img" />
        </section>
    )
}

export default Home;
