export {default as leftArrow} from './left.svg';
export {default as rightArrow} from './right.svg';
export {default as kitty} from './kitty.svg';