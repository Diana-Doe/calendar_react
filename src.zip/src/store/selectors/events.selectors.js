export const getAllEvents = state => state.events;
// викликати селектор в селекторі для того щоб визначити юзера